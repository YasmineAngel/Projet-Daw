<html> 
<head> 

</head>
<body>

<?php
$conn = mysql_connect('localhost' , 'root' , '' , 'base_client') ;

 

$nom = $_POST['nom'] ;
$prenom = $_POST['prenom'] ;
$age = $_POST['age'] ; 
$wilaya =  $_POST['wilaya'] ;
$tel = $_POST['telephone'] ;
$email = $_POST['email'] ;
$adr = $_POST['address'] ;
$password = $_POST['password'] ;
$sex = $_POST['sex'] ;


$ajout = mysql_query($conn , "INSERT INTO Client (No_Clt, Pno_Clt, Age_Clt, Wi_Clt, Tel_Clt, Mail_Clt, Adr_Clt, Mot_Clt, Sexe_Clt)
VALUES ('$nom' , '$prenom' , '$age' , '$wilaya' , '$tel' , '$email', '$adr' , '$password' , '$sex') " ) ;

if ($ajout == true ) {echo "client added successfully ! "  ;}
else  { echo "failed to add client !" . mysqli_error($conn);
} 

mysql_close($conn) ;



  

?>

</body>

</html>
