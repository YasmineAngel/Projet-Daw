<html> 
<head> 

</head>
<body>

<?php
session_start() ;
$conn = mysqli_connect('localhost' , 'root' , '' , 'base_client') ;

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$servername = "localhost" ;
$email = $_POST['email'] ;
$password = $_POST['password'] ;
$dbname = "base_client"

$rech = mysqli_query($conn ,"select * from Client where Mail_Clt = '$email' and Mot_Clt = '$password' ") ;
 
if(mysql_num_rows($rech)>1 )  {
$row = $rech->fetch_assoc() ;
$row = $result->fetch_assoc();
    $_SESSION['Id_Clt'] = $row['Id_Clt'];
    $_SESSION['No_Clt'] = $row['No_Clt'];
    $_SESSION['Pno_Clt'] = $row['Pno_Clt'];
    echo "Authetification successful ! "
}
else echo ("error : failed authentification");




mysqli_close($conn) ;

?>

</body>

</html>
