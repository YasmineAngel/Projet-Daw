html> 
<head> 

</head>
<body>

<?php
$conn = mysqli_connect('localhost' , 'root' , '' , 'base_client') ;
$seller = $_POST['seller'] ;
$price = $_POST['price'] ;
$ref = $_POST['ref'] ;
$color = $_POST['color'] ;
$amount = $_POST['amount'] ;

$add = mysqli_query($conn , "INSERT INTO Commande_produit Values ($seller , $price , $price, $ref , $color , $amount) " ) ;


if ($add == true ) echo("order sent successfully  ! " ) ;
else  echo("failed to send order !") ; 

mysqli_close($conn) ;


?>

</body>

</html>